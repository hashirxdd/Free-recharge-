<?php
// All you need to do is change your payment details in one place
$upi = 'upi id adicho antteth'; // for change your upi id
$receivername = 'Jio plans manager'; // for change receiver name
